package com.sdi.model.user;

public enum UserStatus {
	ACTIVE,
	CANCELLED
}
