# ShareMyTrip2

##Autores
* Carlos Villa (El que nunca hace nadaaa) 
* Serghio El currante

![alt text](http://vignette3.wikia.nocookie.net/thefakegees/images/8/8e/Mlg_Doge.png/revision/latest?cb=20151231000415 "Logo Title Text 1")
