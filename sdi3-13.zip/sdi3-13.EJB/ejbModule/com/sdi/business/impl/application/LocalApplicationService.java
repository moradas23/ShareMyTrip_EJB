package com.sdi.business.impl.application;

import javax.ejb.Local;

import com.sdi.business.ApplicationService;

@Local
public interface LocalApplicationService extends ApplicationService{

}
