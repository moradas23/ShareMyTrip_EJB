package com.sdi.business.impl.user;

import javax.ejb.Local;

import com.sdi.business.UserService;

@Local
public interface LocalUserService extends UserService{

}
