package com.sdi.client.trip;

public enum TripStatus {
	OPEN, 
	CLOSED,
	CANCELLED,
	DONE
}
