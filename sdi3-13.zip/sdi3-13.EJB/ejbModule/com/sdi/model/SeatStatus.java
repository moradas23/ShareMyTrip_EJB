package com.sdi.model;

public enum SeatStatus {
	ACCEPTED,
	EXCLUDED,
	SIN_PLAZA
}
