package com.sdi.business.impl.trip;

import javax.ejb.Remote;

import com.sdi.business.TripService;

@Remote
public interface RemoteTripService extends TripService{

}
