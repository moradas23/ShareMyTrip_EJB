package com.sdi.business.impl.rating;

import javax.ejb.Remote;
import com.sdi.business.RatingService;

@Remote
public interface RemoteRatingService extends RatingService {


}
