package com.sdi.client;

import com.sdi.ui.MainMenu;

public class Main {

	public static void main(String[] args) {
		new MainMenu().execute();
	}

}