public enum SeatStatus {
	ACCEPTED,
	EXCLUDED,
	SIN_PLAZA
}
