package com.sdi.business.impl.seat;

import javax.ejb.Remote;

import com.sdi.business.SeatService;

@Remote
public interface RemoteSeatService extends SeatService{

}
