package com.sdi.model.seat;

public enum SeatStatus {
	ACCEPTED,
	EXCLUDED,
	SIN_PLAZA
}
