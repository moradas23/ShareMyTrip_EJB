package com.sdi.business.impl.login;

import javax.ejb.Local;

import com.sdi.business.LoginService;

@Local
public interface LocalLoginService extends LoginService {

}
