package com.sdi.model;

public enum ImplicacionStatus {
	PROMOTOR,
	PENDIENTE,
	ACEPTADO,
	EXCLUIDO,
	SIN_PLAZA
}
