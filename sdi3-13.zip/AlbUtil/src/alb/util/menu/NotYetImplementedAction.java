package alb.util.menu;



public class NotYetImplementedAction implements Action {

	@Override
	public void execute() throws Exception {
		System.err.println("Opción no implementada");
	}

}
