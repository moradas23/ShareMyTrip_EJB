package com.sdi.business.impl.rating;

import javax.ejb.Local;

import com.sdi.business.RatingService;

@Local
public interface LocalRatingService extends RatingService {

}
