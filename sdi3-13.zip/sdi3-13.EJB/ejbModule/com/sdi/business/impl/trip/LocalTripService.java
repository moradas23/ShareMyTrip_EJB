package com.sdi.business.impl.trip;

import javax.ejb.Local;

import com.sdi.business.TripService;

@Local
public interface LocalTripService extends TripService{

}
