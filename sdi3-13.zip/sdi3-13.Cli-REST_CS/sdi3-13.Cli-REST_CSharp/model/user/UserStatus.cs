public enum UserStatus {
	ACTIVE,
	CANCELLED
}
