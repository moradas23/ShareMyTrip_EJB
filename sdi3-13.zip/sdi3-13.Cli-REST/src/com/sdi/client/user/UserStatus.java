package com.sdi.client.user;

public enum UserStatus {
	ACTIVE,
	CANCELLED
}
