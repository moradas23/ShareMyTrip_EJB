package com.sdi.business.impl.application;

import javax.ejb.Remote;

import com.sdi.business.ApplicationService;

@Remote
public interface RemoteApplicationService extends ApplicationService{

}
