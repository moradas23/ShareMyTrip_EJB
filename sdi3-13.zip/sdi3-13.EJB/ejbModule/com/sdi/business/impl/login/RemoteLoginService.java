package com.sdi.business.impl.login;

import javax.ejb.Remote;
import com.sdi.business.LoginService;


@Remote
public interface RemoteLoginService extends LoginService{

}
