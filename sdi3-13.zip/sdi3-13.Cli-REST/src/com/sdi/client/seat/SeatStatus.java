package com.sdi.client.seat;

public enum SeatStatus {
	ACCEPTED,
	EXCLUDED,
	SIN_PLAZA
}
