package com.sdi.business.impl.seat;

import javax.ejb.Local;

import com.sdi.business.SeatService;

@Local
public interface LocalSeatService extends SeatService{

}
