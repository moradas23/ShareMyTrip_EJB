package com.sdi.model.trip;

public enum TripStatus {
	OPEN, 
	CLOSED,
	CANCELLED,
	DONE
}
