public enum TripStatus {
	OPEN, 
	CLOSED,
	CANCELLED,
	DONE
}
